# AlwaysLose

Minecraft **1.20.1** için Fabric tabanlı, modüler client iskeleti.

## Şu an var olanlar
- Menü tuşu: **Y** (varsayılan). Oyun içinde `Seçenekler > Kontroller > Tuş Atamaları > AlwaysLose` bölümünden değiştirilebilir.
- Yatay, ekrandan biraz küçük menü
- Solda `Combat`, `Render`, `Misc`, `Player` kategorileri; üstlerinde arama çubuğu
- Modüller henüz yok (sonra eklenecek)

## Derleme
Gereksinimler: JDK 17, Gradle 8.5+

```bash
gradle wrapper --gradle-version 8.5   # bir kez, wrapper dosyalarını üretir
./gradlew build
```

Çıktı: `build/libs/alwayslose-0.1.0.jar` (Fabric Loader ve Fabric API ile birlikte `mods` klasörüne at).

Geliştirme için: `./gradlew runClient`

## Yapı
```
src/main/java/com/alwayslose/AlwaysLose.java            giriş noktası + tuş ataması
src/main/java/com/alwayslose/gui/Category.java        kategoriler
src/main/java/com/alwayslose/gui/ClientMenuScreen.java menü ekranı
```
