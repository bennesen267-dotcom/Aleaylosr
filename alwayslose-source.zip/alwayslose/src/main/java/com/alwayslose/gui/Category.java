package com.alwayslose.gui;

import net.minecraft.text.Text;

public enum Category {
    COMBAT("combat"),
    RENDER("render"),
    MISC("misc"),
    PLAYER("player");

    private final String key;

    Category(String key) {
        this.key = key;
    }

    public Text getLabel() {
        return Text.translatable("gui.alwayslose.category." + key);
    }
}
