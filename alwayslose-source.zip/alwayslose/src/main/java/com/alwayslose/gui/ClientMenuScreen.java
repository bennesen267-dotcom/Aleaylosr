package com.alwayslose.gui;

import com.alwayslose.AlwaysLose;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public class ClientMenuScreen extends Screen {
    // Renkler (ARGB)
    private static final int DIM_PANEL      = 0xF0101016;
    private static final int SIDEBAR_BG     = 0xFF16161E;
    private static final int BORDER         = 0xFF2A2A38;
    private static final int ACCENT         = 0xFF6C5CE7;
    private static final int ITEM_HOVER     = 0xFF20202C;
    private static final int ITEM_SELECTED  = 0xFF262636;
    private static final int TEXT_PRIMARY   = 0xFFFFFFFF;
    private static final int TEXT_SECONDARY = 0xFFB0B0C0;
    private static final int TEXT_MUTED     = 0xFF707080;

    // Ölçüler
    private static final int PADDING = 8;
    private static final int SEARCH_H = 18;
    private static final int ITEM_H = 24;
    private static final int ITEM_GAP = 4;

    // Ekran yeniden boyutlanınca korunan durum
    private Category selected = Category.COMBAT;
    private String searchQuery = "";

    private TextFieldWidget searchField;
    private int panelX, panelY, panelW, panelH, sidebarW;

    public ClientMenuScreen() {
        super(Text.translatable("screen.alwayslose.title"));
    }

    @Override
    protected void init() {
        // Ekranın yatay olarak ~%85'i, dikey olarak ~%80'i
        panelW = (int) (width * 0.85);
        panelH = (int) (height * 0.80);
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        sidebarW = Math.max(110, Math.min(160, panelW / 5));

        searchField = new TextFieldWidget(
                textRenderer,
                panelX + PADDING, panelY + PADDING,
                sidebarW - PADDING * 2, SEARCH_H,
                Text.translatable("screen.alwayslose.search")
        );
        searchField.setMaxLength(32);
        searchField.setText(searchQuery);
        updateSuggestion();
        searchField.setChangedListener(text -> {
            searchQuery = text;
            updateSuggestion();
        });
        addDrawableChild(searchField);
    }

    private void updateSuggestion() {
        searchField.setSuggestion(searchField.getText().isEmpty()
                ? Text.translatable("screen.alwayslose.search_hint").getString()
                : null);
    }

    private int categoryY(int index) {
        return panelY + PADDING + SEARCH_H + 12 + index * (ITEM_H + ITEM_GAP);
    }

    private boolean inCategoryRow(int index, double mouseX, double mouseY) {
        int x1 = panelX + PADDING;
        int x2 = panelX + sidebarW - PADDING;
        int y1 = categoryY(index);
        return mouseX >= x1 && mouseX < x2 && mouseY >= y1 && mouseY < y1 + ITEM_H;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);

        // Panel + kenarlık
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, DIM_PANEL);
        ctx.fill(panelX, panelY, panelX + sidebarW, panelY + panelH, SIDEBAR_BG);
        ctx.fill(panelX + sidebarW - 1, panelY, panelX + sidebarW, panelY + panelH, BORDER);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 1, BORDER);
        ctx.fill(panelX, panelY + panelH - 1, panelX + panelW, panelY + panelH, BORDER);
        ctx.fill(panelX, panelY, panelX + 1, panelY + panelH, BORDER);
        ctx.fill(panelX + panelW - 1, panelY, panelX + panelW, panelY + panelH, BORDER);

        // Kategoriler
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x1 = panelX + PADDING;
            int x2 = panelX + sidebarW - PADDING;
            int y1 = categoryY(i);
            int y2 = y1 + ITEM_H;

            boolean isSelected = cats[i] == selected;
            boolean hovered = inCategoryRow(i, mouseX, mouseY);

            if (isSelected) {
                ctx.fill(x1, y1, x2, y2, ITEM_SELECTED);
                ctx.fill(x1, y1, x1 + 2, y2, ACCENT);
            } else if (hovered) {
                ctx.fill(x1, y1, x2, y2, ITEM_HOVER);
            }

            ctx.drawTextWithShadow(textRenderer, cats[i].getLabel(),
                    x1 + 10, y1 + (ITEM_H - 8) / 2,
                    isSelected ? TEXT_PRIMARY : TEXT_SECONDARY);
        }

        // İçerik alanı (modüller sonra buraya gelecek)
        int contentX = panelX + sidebarW + 16;
        int contentY = panelY + 16;
        ctx.drawTextWithShadow(textRenderer, selected.getLabel(), contentX, contentY, TEXT_PRIMARY);
        ctx.fill(contentX, contentY + 14, panelX + panelW - 16, contentY + 15, BORDER);

        Text empty = searchQuery.isEmpty()
                ? Text.translatable("screen.alwayslose.no_modules")
                : Text.translatable("screen.alwayslose.no_results", searchQuery);
        ctx.drawTextWithShadow(textRenderer, empty, contentX, contentY + 26, TEXT_MUTED);

        // Arama çubuğu (widget'lar)
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                if (inCategoryRow(i, mouseX, mouseY)) {
                    if (selected != cats[i]) {
                        selected = cats[i];
                        MinecraftClient.getInstance().getSoundManager()
                                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Arama kutusunda yazmıyorsak, menü tuşu menüyü kapatır
        if (!searchField.isFocused() && AlwaysLose.openMenuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
