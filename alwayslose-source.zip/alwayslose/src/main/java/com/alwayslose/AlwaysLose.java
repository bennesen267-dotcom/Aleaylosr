package com.alwayslose;

import com.alwayslose.gui.ClientMenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class AlwaysLose implements ClientModInitializer {
    public static final String MOD_ID = "alwayslose";

    /** Menu tuşu. Varsayılan Y; Kontroller > Tuş Atamaları'ndan değiştirilebilir. */
    public static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.alwayslose.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_Y,
                "category.alwayslose"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null && client.world != null) {
                    client.setScreen(new ClientMenuScreen());
                }
            }
        });
    }
}
